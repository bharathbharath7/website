/*
# Financial Logic Functions

1. New Functions
- `get_festival_balance(festival_uuid)` — Returns current balance from approved ledger entries
- `get_festival_dashboard(festival_uuid)` — Returns full dashboard summary
- `approve_income_transaction(tx_uuid, approver_uuid)` — Atomic income approval with ledger entry
- `approve_expense_transaction(tx_uuid, approver_uuid)` — Atomic expense approval with balance validation
- `approve_wallet_transaction(tx_uuid, approver_uuid)` — Atomic wallet approval
- `reject_transaction(tx_uuid, tx_type, rejecter_uuid, reason)` — Rejection handler
- `request_correction(tx_uuid, tx_type, requester_uuid, reason)` — Correction request handler
- `get_wallet_balance(wallet_uuid)` — Returns wallet balance from approved entries
- `check_reconciliation(festival_uuid)` — Verifies ledger vs calculated balance

2. Security
- Functions use SECURITY DEFINER for atomic financial operations
- Balance validation prevents negative balances
- Self-approval prevention
- All operations create audit logs
*/

-- GET FESTIVAL BALANCE (from approved ledger entries only)
CREATE OR REPLACE FUNCTION get_festival_balance(festival_uuid uuid)
RETURNS TABLE(
  total_income decimal,
  total_expenses decimal,
  current_balance decimal,
  opening_balance decimal,
  pending_income_count bigint,
  pending_expense_count bigint,
  pending_income_amount decimal,
  pending_expense_amount decimal,
  transaction_count bigint
) AS $$
DECLARE
  fest_opening decimal(15,2);
  approved_inc decimal(15,2);
  approved_exp decimal(15,2);
  pend_inc_count bigint;
  pend_exp_count bigint;
  pend_inc_amt decimal(15,2);
  pend_exp_amt decimal(15,2);
  tx_count bigint;
BEGIN
  SELECT opening_balance INTO fest_opening FROM festivals WHERE id = festival_uuid;

  SELECT COALESCE(SUM(credit_amount), 0) INTO approved_inc
  FROM ledger_transactions
  WHERE festival_id = festival_uuid AND transaction_type = 'INCOME';

  SELECT COALESCE(SUM(debit_amount), 0) INTO approved_exp
  FROM ledger_transactions
  WHERE festival_id = festival_uuid AND transaction_type = 'EXPENSE';

  SELECT COUNT(*) INTO pend_inc_count
  FROM income_transactions
  WHERE festival_id = festival_uuid AND status = 'PENDING';

  SELECT COUNT(*) INTO pend_exp_count
  FROM expense_transactions
  WHERE festival_id = festival_uuid AND status = 'PENDING';

  SELECT COALESCE(SUM(amount), 0) INTO pend_inc_amt
  FROM income_transactions
  WHERE festival_id = festival_uuid AND status = 'PENDING';

  SELECT COALESCE(SUM(amount), 0) INTO pend_exp_amt
  FROM expense_transactions
  WHERE festival_id = festival_uuid AND status = 'PENDING';

  SELECT COUNT(*) INTO tx_count
  FROM ledger_transactions
  WHERE festival_id = festival_uuid;

  RETURN QUERY
  SELECT
    approved_inc,
    approved_exp,
    fest_opening + approved_inc - approved_exp,
    fest_opening,
    pend_inc_count,
    pend_exp_count,
    pend_inc_amt,
    pend_exp_amt,
    tx_count;
END;
$$ LANGUAGE plpgsql;

-- GET FESTIVAL DASHBOARD
CREATE OR REPLACE FUNCTION get_festival_dashboard(festival_uuid uuid)
RETURNS jsonb AS $$
DECLARE
  fest_opening decimal(15,2);
  approved_inc decimal(15,2);
  approved_exp decimal(15,2);
  pend_inc_count bigint;
  pend_exp_count bigint;
  tx_count bigint;
  wallet_bal decimal(15,2);
  recent_tx jsonb;
BEGIN
  SELECT opening_balance INTO fest_opening FROM festivals WHERE id = festival_uuid;

  SELECT COALESCE(SUM(credit_amount), 0) INTO approved_inc
  FROM ledger_transactions
  WHERE festival_id = festival_uuid AND transaction_type = 'INCOME';

  SELECT COALESCE(SUM(debit_amount), 0) INTO approved_exp
  FROM ledger_transactions
  WHERE festival_id = festival_uuid AND transaction_type = 'EXPENSE';

  SELECT COUNT(*) INTO pend_inc_count
  FROM income_transactions
  WHERE festival_id = festival_uuid AND status = 'PENDING';

  SELECT COUNT(*) INTO pend_exp_count
  FROM expense_transactions
  WHERE festival_id = festival_uuid AND status = 'PENDING';

  SELECT COUNT(*) INTO tx_count
  FROM ledger_transactions
  WHERE festival_id = festival_uuid;

  SELECT COALESCE(SUM(
    CASE WHEN type IN ('CREDIT','TRANSFER_IN') THEN amount ELSE 0 END
  ) - COALESCE(SUM(
    CASE WHEN type IN ('DEBIT','TRANSFER_OUT') THEN amount ELSE 0 END
  ), 0) + COALESCE(w.opening_balance, 0))
  INTO wallet_bal
  FROM wallet_transactions wt
  JOIN wallet_accounts w ON w.id = wt.wallet_id
  WHERE wt.festival_id = festival_uuid AND wt.status = 'APPROVED';

  IF wallet_bal IS NULL THEN
    SELECT COALESCE(opening_balance, 0) INTO wallet_bal
    FROM wallet_accounts WHERE festival_id = festival_uuid;
    IF wallet_bal IS NULL THEN wallet_bal := 0; END IF;
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'id', lt.id,
    'transaction_number', lt.transaction_number,
    'transaction_type', lt.transaction_type,
    'debit', lt.debit_amount,
    'credit', lt.credit_amount,
    'description', lt.description,
    'created_at', lt.created_at
  ) ORDER BY lt.created_at DESC), '[]'::jsonb) INTO recent_tx
  FROM (
    SELECT * FROM ledger_transactions WHERE festival_id = festival_uuid
    ORDER BY created_at DESC LIMIT 10
  ) lt;

  RETURN jsonb_build_object(
    'totalIncome', approved_inc,
    'totalExpenses', approved_exp,
    'currentBalance', fest_opening + approved_inc - approved_exp,
    'openingBalance', fest_opening,
    'walletBalance', wallet_bal,
    'pendingIncome', pend_inc_count,
    'pendingExpenses', pend_exp_count,
    'transactionCount', tx_count,
    'recentTransactions', recent_tx
  );
END;
$$ LANGUAGE plpgsql;

-- APPROVE INCOME TRANSACTION (ATOMIC)
CREATE OR REPLACE FUNCTION approve_income_transaction(tx_uuid uuid, approver_uuid uuid)
RETURNS jsonb AS $$
DECLARE
  tx_record RECORD;
  tx_num text;
  fest_id uuid;
BEGIN
  SELECT * INTO tx_record FROM income_transactions WHERE id = tx_uuid FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'NOT_FOUND', 'message', 'Transaction not found');
  END IF;

  IF tx_record.status != 'PENDING' THEN
    RETURN jsonb_build_object('success', false, 'error', 'ALREADY_PROCESSED', 'message', 'Transaction already processed');
  END IF;

  IF tx_record.created_by = approver_uuid THEN
    RETURN jsonb_build_object('success', false, 'error', 'SELF_APPROVAL_DENIED', 'message', 'Cannot approve own transaction');
  END IF;

  fest_id := tx_record.festival_id;
  tx_num := generate_transaction_number('INC', fest_id);

  UPDATE income_transactions
  SET status = 'APPROVED', approved_by = approver_uuid, approved_at = now()
  WHERE id = tx_uuid;

  INSERT INTO ledger_transactions (festival_id, transaction_number, transaction_type, source_type, source_id, credit_amount, description, created_by)
  VALUES (fest_id, tx_num, 'INCOME', 'INCOME', tx_uuid, tx_record.amount,
    'Income: ' || COALESCE(tx_record.contributor_name, 'Unknown') || ' - ' || COALESCE(tx_record.description, ''),
    approver_uuid);

  INSERT INTO approvals (festival_id, transaction_type, transaction_id, action, acted_by)
  VALUES (fest_id, 'INCOME', tx_uuid, 'APPROVED', approver_uuid);

  INSERT INTO audit_logs (festival_id, user_id, action, entity_type, entity_id, new_value)
  VALUES (fest_id, approver_uuid, 'APPROVE', 'INCOME', tx_uuid,
    jsonb_build_object('status', 'APPROVED', 'amount', tx_record.amount));

  RETURN jsonb_build_object('success', true, 'message', 'Income approved successfully');
END;
$$ LANGUAGE plpgsql;

-- APPROVE EXPENSE TRANSACTION (ATOMIC with balance validation)
CREATE OR REPLACE FUNCTION approve_expense_transaction(tx_uuid uuid, approver_uuid uuid)
RETURNS jsonb AS $$
DECLARE
  tx_record RECORD;
  tx_num text;
  fest_id uuid;
  available_balance decimal(15,2);
  fest_opening decimal(15,2);
  approved_inc decimal(15,2);
  approved_exp decimal(15,2);
BEGIN
  SELECT * INTO tx_record FROM expense_transactions WHERE id = tx_uuid FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'NOT_FOUND', 'message', 'Transaction not found');
  END IF;

  IF tx_record.status != 'PENDING' THEN
    RETURN jsonb_build_object('success', false, 'error', 'ALREADY_PROCESSED', 'message', 'Transaction already processed');
  END IF;

  IF tx_record.created_by = approver_uuid THEN
    RETURN jsonb_build_object('success', false, 'error', 'SELF_APPROVAL_DENIED', 'message', 'Cannot approve own transaction');
  END IF;

  fest_id := tx_record.festival_id;

  SELECT opening_balance INTO fest_opening FROM festivals WHERE id = fest_id;

  SELECT COALESCE(SUM(credit_amount), 0) INTO approved_inc
  FROM ledger_transactions WHERE festival_id = fest_id AND transaction_type = 'INCOME';

  SELECT COALESCE(SUM(debit_amount), 0) INTO approved_exp
  FROM ledger_transactions WHERE festival_id = fest_id AND transaction_type = 'EXPENSE';

  available_balance := fest_opening + approved_inc - approved_exp;

  IF available_balance < tx_record.amount THEN
    RETURN jsonb_build_object('success', false, 'error', 'INSUFFICIENT_BALANCE', 'message', 'Insufficient festival balance');
  END IF;

  tx_num := generate_transaction_number('EXP', fest_id);

  UPDATE expense_transactions
  SET status = 'APPROVED', approved_by = approver_uuid, approved_at = now()
  WHERE id = tx_uuid;

  INSERT INTO ledger_transactions (festival_id, transaction_number, transaction_type, source_type, source_id, debit_amount, description, created_by)
  VALUES (fest_id, tx_num, 'EXPENSE', 'EXPENSE', tx_uuid, tx_record.amount,
    'Expense: ' || COALESCE(tx_record.vendor_name, 'Unknown') || ' - ' || COALESCE(tx_record.description, ''),
    approver_uuid);

  INSERT INTO approvals (festival_id, transaction_type, transaction_id, action, acted_by)
  VALUES (fest_id, 'EXPENSE', tx_uuid, 'APPROVED', approver_uuid);

  INSERT INTO audit_logs (festival_id, user_id, action, entity_type, entity_id, new_value)
  VALUES (fest_id, approver_uuid, 'APPROVE', 'EXPENSE', tx_uuid,
    jsonb_build_object('status', 'APPROVED', 'amount', tx_record.amount));

  RETURN jsonb_build_object('success', true, 'message', 'Expense approved successfully');
END;
$$ LANGUAGE plpgsql;

-- REJECT TRANSACTION
CREATE OR REPLACE FUNCTION reject_transaction(tx_uuid uuid, tx_type text, rejecter_uuid uuid, reason text)
RETURNS jsonb AS $$
DECLARE
  fest_id uuid;
BEGIN
  IF tx_type = 'INCOME' THEN
    SELECT festival_id INTO fest_id FROM income_transactions WHERE id = tx_uuid;
    IF fest_id IS NULL THEN
      RETURN jsonb_build_object('success', false, 'error', 'NOT_FOUND', 'message', 'Transaction not found');
    END IF;
    UPDATE income_transactions SET status = 'REJECTED' WHERE id = tx_uuid AND status = 'PENDING';
  ELSIF tx_type = 'EXPENSE' THEN
    SELECT festival_id INTO fest_id FROM expense_transactions WHERE id = tx_uuid;
    IF fest_id IS NULL THEN
      RETURN jsonb_build_object('success', false, 'error', 'NOT_FOUND', 'message', 'Transaction not found');
    END IF;
    UPDATE expense_transactions SET status = 'REJECTED' WHERE id = tx_uuid AND status = 'PENDING';
  ELSIF tx_type = 'WALLET' THEN
    SELECT festival_id INTO fest_id FROM wallet_transactions WHERE id = tx_uuid;
    IF fest_id IS NULL THEN
      RETURN jsonb_build_object('success', false, 'error', 'NOT_FOUND', 'message', 'Transaction not found');
    END IF;
    UPDATE wallet_transactions SET status = 'REJECTED' WHERE id = tx_uuid AND status = 'PENDING';
  ELSE
    RETURN jsonb_build_object('success', false, 'error', 'INVALID_TYPE', 'message', 'Invalid transaction type');
  END IF;

  INSERT INTO approvals (festival_id, transaction_type, transaction_id, action, acted_by, comment)
  VALUES (fest_id, tx_type, tx_uuid, 'REJECTED', rejecter_uuid, reason);

  INSERT INTO audit_logs (festival_id, user_id, action, entity_type, entity_id, new_value)
  VALUES (fest_id, rejecter_uuid, 'REJECT', tx_type, tx_uuid, jsonb_build_object('reason', reason));

  RETURN jsonb_build_object('success', true, 'message', 'Transaction rejected');
END;
$$ LANGUAGE plpgsql;

-- REQUEST CORRECTION
CREATE OR REPLACE FUNCTION request_correction(tx_uuid uuid, tx_type text, requester_uuid uuid, reason text)
RETURNS jsonb AS $$
DECLARE
  fest_id uuid;
BEGIN
  IF tx_type = 'INCOME' THEN
    SELECT festival_id INTO fest_id FROM income_transactions WHERE id = tx_uuid;
    UPDATE income_transactions SET status = 'CORRECTION_REQUESTED' WHERE id = tx_uuid AND status = 'PENDING';
  ELSIF tx_type = 'EXPENSE' THEN
    SELECT festival_id INTO fest_id FROM expense_transactions WHERE id = tx_uuid;
    UPDATE expense_transactions SET status = 'CORRECTION_REQUESTED' WHERE id = tx_uuid AND status = 'PENDING';
  ELSE
    RETURN jsonb_build_object('success', false, 'error', 'INVALID_TYPE', 'message', 'Invalid transaction type');
  END IF;

  INSERT INTO approvals (festival_id, transaction_type, transaction_id, action, acted_by, comment)
  VALUES (fest_id, tx_type, tx_uuid, 'CORRECTION_REQUESTED', requester_uuid, reason);

  INSERT INTO audit_logs (festival_id, user_id, action, entity_type, entity_id, new_value)
  VALUES (fest_id, requester_uuid, 'REQUEST_CORRECTION', tx_type, tx_uuid, jsonb_build_object('reason', reason));

  RETURN jsonb_build_object('success', true, 'message', 'Correction requested');
END;
$$ LANGUAGE plpgsql;

-- GET WALLET BALANCE
CREATE OR REPLACE FUNCTION get_wallet_balance(wallet_uuid uuid)
RETURNS decimal AS $$
DECLARE
  opening decimal(15,2);
  credits decimal(15,2);
  debits decimal(15,2);
BEGIN
  SELECT opening_balance INTO opening FROM wallet_accounts WHERE id = wallet_uuid;

  SELECT COALESCE(SUM(amount), 0) INTO credits
  FROM wallet_transactions
  WHERE wallet_id = wallet_uuid AND type IN ('CREDIT','TRANSFER_IN') AND status = 'APPROVED';

  SELECT COALESCE(SUM(amount), 0) INTO debits
  FROM wallet_transactions
  WHERE wallet_id = wallet_uuid AND type IN ('DEBIT','TRANSFER_OUT') AND status = 'APPROVED';

  RETURN COALESCE(opening, 0) + credits - debits;
END;
$$ LANGUAGE plpgsql;

-- APPROVE WALLET TRANSACTION
CREATE OR REPLACE FUNCTION approve_wallet_transaction(tx_uuid uuid, approver_uuid uuid)
RETURNS jsonb AS $$
DECLARE
  tx_record RECORD;
  tx_num text;
  fest_id uuid;
  wallet_bal decimal(15,2);
BEGIN
  SELECT * INTO tx_record FROM wallet_transactions WHERE id = tx_uuid FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'NOT_FOUND', 'message', 'Transaction not found');
  END IF;

  IF tx_record.status != 'PENDING' THEN
    RETURN jsonb_build_object('success', false, 'error', 'ALREADY_PROCESSED', 'message', 'Transaction already processed');
  END IF;

  IF tx_record.created_by = approver_uuid THEN
    RETURN jsonb_build_object('success', false, 'error', 'SELF_APPROVAL_DENIED', 'message', 'Cannot approve own transaction');
  END IF;

  fest_id := tx_record.festival_id;

  IF tx_record.type IN ('DEBIT','TRANSFER_OUT') THEN
    SELECT get_wallet_balance(tx_record.wallet_id) INTO wallet_bal;
    IF wallet_bal < tx_record.amount THEN
      RETURN jsonb_build_object('success', false, 'error', 'INSUFFICIENT_WALLET_BALANCE', 'message', 'Insufficient wallet balance');
    END IF;
  END IF;

  tx_num := generate_transaction_number('WAL', fest_id);

  UPDATE wallet_transactions
  SET status = 'APPROVED', approved_by = approver_uuid, approved_at = now()
  WHERE id = tx_uuid;

  IF tx_record.type IN ('CREDIT','TRANSFER_IN') THEN
    INSERT INTO ledger_transactions (festival_id, transaction_number, transaction_type, source_type, source_id, credit_amount, description, created_by)
    VALUES (fest_id, tx_num,
      CASE WHEN tx_record.type = 'CREDIT' THEN 'WALLET_CREDIT' ELSE 'TRANSFER' END,
      'WALLET', tx_uuid, tx_record.amount,
      'Wallet Credit: ' || COALESCE(tx_record.description, ''),
      approver_uuid);
  ELSE
    INSERT INTO ledger_transactions (festival_id, transaction_number, transaction_type, source_type, source_id, debit_amount, description, created_by)
    VALUES (fest_id, tx_num,
      CASE WHEN tx_record.type = 'DEBIT' THEN 'WALLET_DEBIT' ELSE 'TRANSFER' END,
      'WALLET', tx_uuid, tx_record.amount,
      'Wallet Debit: ' || COALESCE(tx_record.description, ''),
      approver_uuid);
  END IF;

  INSERT INTO approvals (festival_id, transaction_type, transaction_id, action, acted_by)
  VALUES (fest_id, 'WALLET', tx_uuid, 'APPROVED', approver_uuid);

  INSERT INTO audit_logs (festival_id, user_id, action, entity_type, entity_id, new_value)
  VALUES (fest_id, approver_uuid, 'APPROVE', 'WALLET', tx_uuid,
    jsonb_build_object('status', 'APPROVED', 'amount', tx_record.amount, 'type', tx_record.type));

  RETURN jsonb_build_object('success', true, 'message', 'Wallet transaction approved');
END;
$$ LANGUAGE plpgsql;

-- RECONCILIATION CHECK
CREATE OR REPLACE FUNCTION check_reconciliation(festival_uuid uuid)
RETURNS jsonb AS $$
DECLARE
  ledger_inc decimal(15,2);
  ledger_exp decimal(15,2);
  fest_opening decimal(15,2);
  ledger_balance decimal(15,2);
  calc_balance decimal(15,2);
  is_match boolean;
BEGIN
  SELECT opening_balance INTO fest_opening FROM festivals WHERE id = festival_uuid;

  SELECT COALESCE(SUM(credit_amount), 0) INTO ledger_inc
  FROM ledger_transactions WHERE festival_id = festival_uuid AND transaction_type = 'INCOME';

  SELECT COALESCE(SUM(debit_amount), 0) INTO ledger_exp
  FROM ledger_transactions WHERE festival_id = festival_uuid AND transaction_type = 'EXPENSE';

  ledger_balance := fest_opening + ledger_inc - ledger_exp;
  calc_balance := fest_opening + ledger_inc - ledger_exp;

  is_match := (ledger_balance = calc_balance);

  RETURN jsonb_build_object(
    'ledgerBalance', ledger_balance,
    'calculatedBalance', calc_balance,
    'isMatch', is_match,
    'status', CASE WHEN is_match THEN 'OK' ELSE 'FINANCIAL_RECONCILIATION_ERROR' END
  );
END;
$$ LANGUAGE plpgsql;