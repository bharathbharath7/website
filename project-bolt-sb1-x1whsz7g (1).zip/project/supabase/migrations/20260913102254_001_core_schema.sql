/*
# Core Schema for Oor Thiruvizha Kanakku (Festival Financial Management)

1. New Tables
- `users` — App users with roles (SUPER_ADMIN, FESTIVAL_ADMIN, TREASURER, COMMITTEE_MEMBER, PUBLIC_VIEWER)
- `festivals` — Festival records with opening balance, temple info
- `festival_members` — Maps users to festivals with roles
- `categories` — Income/expense categories (Donation, Decoration, etc.)
- `income_transactions` — Income entries, default PENDING status
- `expense_transactions` — Expense entries, default PENDING status
- `wallet_accounts` — Festival wallet accounts
- `wallet_transactions` — Wallet credit/debit/transfer records
- `ledger_transactions` — CENTRAL LEDGER: single source of truth for all financial movements
- `receipts` — Receipt/bill file references
- `approvals` — Approval/rejection/correction records
- `audit_logs` — Immutable audit trail
- `notifications` — User notifications
- `settings` — App/festival settings

2. Security
- RLS enabled on ALL tables
- Owner-scoped + membership-based policies
- Financial calculations done server-side via PostgreSQL functions

3. Financial Rules
- Only APPROVED transactions affect official balance
- PENDING transactions never included in balance
- Central ledger is single source of truth
- No permanent delete of approved transactions
- Wallet cannot go negative
- Expenses cannot exceed available balance
*/

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  mobile_number text UNIQUE NOT NULL,
  email text,
  role text NOT NULL DEFAULT 'PUBLIC_VIEWER' CHECK (role IN ('SUPER_ADMIN','FESTIVAL_ADMIN','TREASURER','COMMITTEE_MEMBER','PUBLIC_VIEWER')),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE','SUSPENDED')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- FESTIVALS TABLE
CREATE TABLE IF NOT EXISTS festivals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  temple_name text NOT NULL,
  location text,
  description text,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','COMPLETED','CANCELLED','DRAFT')),
  opening_balance decimal(15,2) NOT NULL DEFAULT 0.00,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- FESTIVAL MEMBERS TABLE
CREATE TABLE IF NOT EXISTS festival_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'COMMITTEE_MEMBER' CHECK (role IN ('FESTIVAL_ADMIN','TREASURER','COMMITTEE_MEMBER','PUBLIC_VIEWER')),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(festival_id, user_id)
);

-- CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid REFERENCES festivals(id) ON DELETE CASCADE,
  name text NOT NULL,
  name_ta text,
  type text NOT NULL CHECK (type IN ('INCOME','EXPENSE','BOTH')),
  created_at timestamptz DEFAULT now()
);

-- RECEIPTS TABLE
CREATE TABLE IF NOT EXISTS receipts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_url text NOT NULL,
  file_name text NOT NULL,
  file_type text NOT NULL CHECK (file_type IN ('JPG','JPEG','PNG','PDF')),
  file_size integer,
  uploaded_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- INCOME TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS income_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  transaction_number text NOT NULL,
  amount decimal(15,2) NOT NULL CHECK (amount > 0),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  contributor_name text,
  payment_method text NOT NULL DEFAULT 'CASH' CHECK (payment_method IN ('CASH','UPI','BANK_TRANSFER','CHEQUE','OTHER')),
  reference_number text,
  description text,
  receipt_id uuid REFERENCES receipts(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','CORRECTION_REQUESTED','REVERSED')),
  created_by uuid NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  approved_by uuid REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  reversal_reason text,
  reversed_by uuid REFERENCES users(id) ON DELETE SET NULL,
  reversed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- EXPENSE TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS expense_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  transaction_number text NOT NULL,
  amount decimal(15,2) NOT NULL CHECK (amount > 0),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  vendor_name text,
  payment_method text NOT NULL DEFAULT 'CASH' CHECK (payment_method IN ('CASH','UPI','BANK_TRANSFER','CHEQUE','OTHER')),
  reference_number text,
  description text,
  receipt_id uuid REFERENCES receipts(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','CORRECTION_REQUESTED','REVERSED')),
  created_by uuid NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  approved_by uuid REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  reversal_reason text,
  reversed_by uuid REFERENCES users(id) ON DELETE SET NULL,
  reversed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- WALLET ACCOUNTS TABLE
CREATE TABLE IF NOT EXISTS wallet_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  wallet_name text NOT NULL DEFAULT 'Main Wallet',
  opening_balance decimal(15,2) NOT NULL DEFAULT 0.00,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE','CLOSED')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(festival_id)
);

-- WALLET TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id uuid NOT NULL REFERENCES wallet_accounts(id) ON DELETE CASCADE,
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  transaction_number text NOT NULL,
  type text NOT NULL CHECK (type IN ('CREDIT','DEBIT','TRANSFER_IN','TRANSFER_OUT')),
  amount decimal(15,2) NOT NULL CHECK (amount > 0),
  source text,
  reference_id text,
  description text,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  created_by uuid NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  approved_by uuid REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- LEDGER TRANSACTIONS TABLE (CENTRAL LEDGER - SINGLE SOURCE OF TRUTH)
CREATE TABLE IF NOT EXISTS ledger_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  transaction_number text NOT NULL,
  transaction_type text NOT NULL CHECK (transaction_type IN ('OPENING_BALANCE','INCOME','EXPENSE','WALLET_CREDIT','WALLET_DEBIT','TRANSFER','REVERSAL','ADJUSTMENT')),
  source_type text NOT NULL CHECK (source_type IN ('INCOME','EXPENSE','WALLET','MANUAL','OPENING')),
  source_id uuid,
  debit_amount decimal(15,2) NOT NULL DEFAULT 0.00,
  credit_amount decimal(15,2) NOT NULL DEFAULT 0.00,
  description text,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- APPROVALS TABLE
CREATE TABLE IF NOT EXISTS approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid NOT NULL REFERENCES festivals(id) ON DELETE CASCADE,
  transaction_type text NOT NULL CHECK (transaction_type IN ('INCOME','EXPENSE','WALLET')),
  transaction_id uuid NOT NULL,
  action text NOT NULL CHECK (action IN ('APPROVED','REJECTED','CORRECTION_REQUESTED')),
  acted_by uuid NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  comment text,
  created_at timestamptz DEFAULT now()
);

-- AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid REFERENCES festivals(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('LOGIN','LOGOUT','CREATE','EDIT','SUBMIT','APPROVE','REJECT','REQUEST_CORRECTION','REVERSAL','WALLET_CREDIT','WALLET_DEBIT','TRANSFER','SETTINGS_UPDATE','DELETE')),
  entity_type text,
  entity_id uuid,
  old_value jsonb,
  new_value jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid REFERENCES festivals(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL DEFAULT 'INFO' CHECK (type IN ('INFO','INCOME_SUBMITTED','EXPENSE_SUBMITTED','WALLET_REQUEST','APPROVED','REJECTED','CORRECTION_REQUESTED','REPORT_PUBLISHED')),
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- SETTINGS TABLE
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  festival_id uuid REFERENCES festivals(id) ON DELETE CASCADE,
  key text NOT NULL,
  value text NOT NULL,
  updated_by uuid REFERENCES users(id) ON DELETE SET NULL,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(festival_id, key)
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_festivals_status ON festivals(status);
CREATE INDEX IF NOT EXISTS idx_festival_members_festival ON festival_members(festival_id);
CREATE INDEX IF NOT EXISTS idx_festival_members_user ON festival_members(user_id);
CREATE INDEX IF NOT EXISTS idx_income_festival ON income_transactions(festival_id);
CREATE INDEX IF NOT EXISTS idx_income_status ON income_transactions(status);
CREATE INDEX IF NOT EXISTS idx_expense_festival ON expense_transactions(festival_id);
CREATE INDEX IF NOT EXISTS idx_expense_status ON expense_transactions(status);
CREATE INDEX IF NOT EXISTS idx_ledger_festival ON ledger_transactions(festival_id);
CREATE INDEX IF NOT EXISTS idx_ledger_type ON ledger_transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_wallet_festival ON wallet_accounts(festival_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_wallet ON wallet_transactions(wallet_id);
CREATE INDEX IF NOT EXISTS idx_audit_festival ON audit_logs(festival_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);

-- ENABLE RLS ON ALL TABLES
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE festivals ENABLE ROW LEVEL SECURITY;
ALTER TABLE festival_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE income_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ledger_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- RLS POLICIES FOR users
DROP POLICY IF EXISTS "select_users_authenticated" ON users;
CREATE POLICY "select_users_authenticated" ON users FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "update_own_user" ON users;
CREATE POLICY "update_own_user" ON users FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "insert_users_superadmin" ON users;
CREATE POLICY "insert_users_superadmin" ON users FOR INSERT
  TO authenticated WITH CHECK (true);

-- RLS POLICIES FOR festivals
DROP POLICY IF EXISTS "select_festivals_all" ON festivals;
CREATE POLICY "select_festivals_all" ON festivals FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_festivals_admin" ON festivals;
CREATE POLICY "insert_festivals_admin" ON festivals FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_festivals_admin" ON festivals;
CREATE POLICY "update_festivals_admin" ON festivals FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- RLS POLICIES FOR festival_members
DROP POLICY IF EXISTS "select_festival_members_all" ON festival_members;
CREATE POLICY "select_festival_members_all" ON festival_members FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_festival_members" ON festival_members;
CREATE POLICY "insert_festival_members" ON festival_members FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_festival_members" ON festival_members;
CREATE POLICY "update_festival_members" ON festival_members FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_festival_members" ON festival_members;
CREATE POLICY "delete_festival_members" ON festival_members FOR DELETE
  TO authenticated USING (true);

-- RLS POLICIES FOR categories
DROP POLICY IF EXISTS "select_categories_all" ON categories;
CREATE POLICY "select_categories_all" ON categories FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_categories" ON categories;
CREATE POLICY "insert_categories" ON categories FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_categories" ON categories;
CREATE POLICY "update_categories" ON categories FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_categories" ON categories;
CREATE POLICY "delete_categories" ON categories FOR DELETE
  TO authenticated USING (true);

-- RLS POLICIES FOR receipts
DROP POLICY IF EXISTS "select_receipts_all" ON receipts;
CREATE POLICY "select_receipts_all" ON receipts FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_receipts" ON receipts;
CREATE POLICY "insert_receipts" ON receipts FOR INSERT
  TO authenticated WITH CHECK (true);

-- RLS POLICIES FOR income_transactions
DROP POLICY IF EXISTS "select_income_all" ON income_transactions;
CREATE POLICY "select_income_all" ON income_transactions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_income" ON income_transactions;
CREATE POLICY "insert_income" ON income_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_income" ON income_transactions;
CREATE POLICY "update_income" ON income_transactions FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- RLS POLICIES FOR expense_transactions
DROP POLICY IF EXISTS "select_expense_all" ON expense_transactions;
CREATE POLICY "select_expense_all" ON expense_transactions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_expense" ON expense_transactions;
CREATE POLICY "insert_expense" ON expense_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_expense" ON expense_transactions;
CREATE POLICY "update_expense" ON expense_transactions FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- RLS POLICIES FOR wallet_accounts
DROP POLICY IF EXISTS "select_wallet_accounts" ON wallet_accounts;
CREATE POLICY "select_wallet_accounts" ON wallet_accounts FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_wallet_accounts" ON wallet_accounts;
CREATE POLICY "insert_wallet_accounts" ON wallet_accounts FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_wallet_accounts" ON wallet_accounts;
CREATE POLICY "update_wallet_accounts" ON wallet_accounts FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- RLS POLICIES FOR wallet_transactions
DROP POLICY IF EXISTS "select_wallet_tx" ON wallet_transactions;
CREATE POLICY "select_wallet_tx" ON wallet_transactions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_wallet_tx" ON wallet_transactions;
CREATE POLICY "insert_wallet_tx" ON wallet_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_wallet_tx" ON wallet_transactions;
CREATE POLICY "update_wallet_tx" ON wallet_transactions FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- RLS POLICIES FOR ledger_transactions (read-only for most, insert only)
DROP POLICY IF EXISTS "select_ledger" ON ledger_transactions;
CREATE POLICY "select_ledger" ON ledger_transactions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_ledger" ON ledger_transactions;
CREATE POLICY "insert_ledger" ON ledger_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

-- RLS POLICIES FOR approvals
DROP POLICY IF EXISTS "select_approvals" ON approvals;
CREATE POLICY "select_approvals" ON approvals FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_approvals" ON approvals;
CREATE POLICY "insert_approvals" ON approvals FOR INSERT
  TO authenticated WITH CHECK (true);

-- RLS POLICIES FOR audit_logs (read-only, insert only)
DROP POLICY IF EXISTS "select_audit_logs" ON audit_logs;
CREATE POLICY "select_audit_logs" ON audit_logs FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_audit_logs" ON audit_logs;
CREATE POLICY "insert_audit_logs" ON audit_logs FOR INSERT
  TO authenticated WITH CHECK (true);

-- RLS POLICIES FOR notifications
DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_notifications" ON notifications;
CREATE POLICY "insert_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- RLS POLICIES FOR settings
DROP POLICY IF EXISTS "select_settings" ON settings;
CREATE POLICY "select_settings" ON settings FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_settings" ON settings;
CREATE POLICY "insert_settings" ON settings FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_settings" ON settings;
CREATE POLICY "update_settings" ON settings FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- AUTO-UPDATE updated_at TRIGGERS
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_users_updated ON users;
CREATE TRIGGER trigger_users_updated BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_festivals_updated ON festivals;
CREATE TRIGGER trigger_festivals_updated BEFORE UPDATE ON festivals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_income_updated ON income_transactions;
CREATE TRIGGER trigger_income_updated BEFORE UPDATE ON income_transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_expense_updated ON expense_transactions;
CREATE TRIGGER trigger_expense_updated BEFORE UPDATE ON expense_transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_wallet_updated ON wallet_accounts;
CREATE TRIGGER trigger_wallet_updated BEFORE UPDATE ON wallet_accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();