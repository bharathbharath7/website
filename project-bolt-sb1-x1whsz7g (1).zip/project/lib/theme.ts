export const Colors = {
  primary: '#D4A017',
  primaryDark: '#B8860B',
  primaryLight: '#F4D03F',
  primarySoft: '#FEF5E7',
  secondary: '#1B5E20',
  secondaryLight: '#4CAF50',
  accent: '#FF6F00',
  success: '#2E7D32',
  successLight: '#E8F5E9',
  warning: '#F57F17',
  warningLight: '#FFF8E1',
  error: '#C62828',
  errorLight: '#FFEBEE',
  info: '#1565C0',
  infoLight: '#E3F2FD',
  pending: '#FF8F00',
  approved: '#2E7D32',
  rejected: '#C62828',
  background: '#FAFAFA',
  surface: '#FFFFFF',
  surfaceAlt: '#F5F5F5',
  border: '#E0E0E0',
  borderLight: '#EEEEEE',
  textPrimary: '#1A1A1A',
  textSecondary: '#666666',
  textTertiary: '#999999',
  textOnPrimary: '#FFFFFF',
  textOnDark: '#FFFFFF',
  overlay: 'rgba(0,0,0,0.5)',
  shadow: 'rgba(0,0,0,0.08)',
  shadowDark: 'rgba(0,0,0,0.16)',
  gradientStart: '#D4A017',
  gradientEnd: '#B8860B',
  gradientDarkStart: '#1A1A1A',
  gradientDarkEnd: '#2D2D2D',
  temple: '#8B4513',
  templeLight: '#DEB887',
  festival: '#FF6F00',
  festivalLight: '#FFF3E0',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  huge: 40,
};

export const FontSizes = {
  caption: 12,
  body: 14,
  bodyLarge: 16,
  subtitle: 18,
  title: 20,
  heading: 24,
  largeHeading: 28,
  huge: 36,
  mega: 48,
};

export const BorderRadius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 20,
  xxl: 28,
  round: 999,
};

export const FontWeight = {
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
};

export const ShadowStyles = {
  small: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 3,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 4,
  },
  large: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 8,
  },
};
