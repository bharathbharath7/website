import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from './supabase';
import type { User, Festival, Language } from './types';

interface AuthContextType {
  user: User | null;
  festival: Festival | null;
  language: Language;
  loading: boolean;
  setFestival: (festival: Festival | null) => void;
  setLanguage: (lang: Language) => void;
  signIn: (mobile: string) => Promise<{ error: string | null }>;
  verifyOtp: (mobile: string, otp: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [festival, setFestival] = useState<Festival | null>(null);
  const [language, setLanguageState] = useState<Language>('ta');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function init() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session && mounted) {
          await loadUser(session.user.id);
        }
      } catch (e) {
        // ignore
      } finally {
        if (mounted) setLoading(false);
      }
    }

    init();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      (async () => {
        if (event === 'SIGNED_OUT' || !session) {
          setUser(null);
          setFestival(null);
        } else if (session) {
          await loadUser(session.user.id);
        }
      })();
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  async function loadUser(userId: string) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (!error && data) {
        setUser(data as User);
      }
    } catch (e) {
      // ignore
    }
  }

  async function signIn(mobile: string) {
    try {
      const { error } = await supabase.auth.signInWithOtp({
        phone: '+91' + mobile,
      });
      return { error: error?.message || null };
    } catch (e: any) {
      return { error: e.message };
    }
  }

  async function verifyOtp(mobile: string, otp: string) {
    try {
      const { error } = await supabase.auth.verifyOtp({
        phone: '+91' + mobile,
        token: otp,
        type: 'sms',
      });
      if (error) return { error: error.message };

      const { data: session } = await supabase.auth.getSession();
      if (session?.user) {
        await loadUser(session.user.id);
      }
      return { error: null };
    } catch (e: any) {
      return { error: e.message };
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    setUser(null);
    setFestival(null);
  }

  async function refreshUser() {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      await loadUser(session.user.id);
    }
  }

  function setLanguage(lang: Language) {
    setLanguageState(lang);
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        festival,
        language,
        loading,
        setFestival,
        setLanguage,
        signIn,
        verifyOtp,
        signOut,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
