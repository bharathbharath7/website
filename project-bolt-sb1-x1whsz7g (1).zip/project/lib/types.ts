export type UserRole = 'SUPER_ADMIN' | 'FESTIVAL_ADMIN' | 'TREASURER' | 'COMMITTEE_MEMBER' | 'PUBLIC_VIEWER';

export type TransactionStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CORRECTION_REQUESTED' | 'REVERSED';

export type PaymentMethod = 'CASH' | 'UPI' | 'BANK_TRANSFER' | 'CHEQUE' | 'OTHER';

export type LedgerType = 'OPENING_BALANCE' | 'INCOME' | 'EXPENSE' | 'WALLET_CREDIT' | 'WALLET_DEBIT' | 'TRANSFER' | 'REVERSAL' | 'ADJUSTMENT';

export type WalletTxType = 'CREDIT' | 'DEBIT' | 'TRANSFER_IN' | 'TRANSFER_OUT';

export type FestivalStatus = 'ACTIVE' | 'COMPLETED' | 'CANCELLED' | 'DRAFT';

export interface User {
  id: string;
  name: string;
  mobile_number: string;
  email: string | null;
  role: UserRole;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface Festival {
  id: string;
  name: string;
  temple_name: string;
  location: string | null;
  description: string | null;
  start_date: string;
  end_date: string;
  status: FestivalStatus;
  opening_balance: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface FestivalMember {
  id: string;
  festival_id: string;
  user_id: string;
  role: string;
  status: string;
  joined_at: string;
  user?: User;
}

export interface Category {
  id: string;
  festival_id: string | null;
  name: string;
  name_ta: string | null;
  type: 'INCOME' | 'EXPENSE' | 'BOTH';
  created_at: string;
}

export interface IncomeTransaction {
  id: string;
  festival_id: string;
  transaction_number: string;
  amount: number;
  category_id: string | null;
  contributor_name: string | null;
  payment_method: PaymentMethod;
  reference_number: string | null;
  description: string | null;
  receipt_id: string | null;
  status: TransactionStatus;
  created_by: string;
  approved_by: string | null;
  approved_at: string | null;
  reversal_reason: string | null;
  reversed_by: string | null;
  reversed_at: string | null;
  created_at: string;
  updated_at: string;
  category?: Category;
  creator?: { name: string };
  approver?: { name: string } | null;
}

export interface ExpenseTransaction {
  id: string;
  festival_id: string;
  transaction_number: string;
  amount: number;
  category_id: string | null;
  vendor_name: string | null;
  payment_method: PaymentMethod;
  reference_number: string | null;
  description: string | null;
  receipt_id: string | null;
  status: TransactionStatus;
  created_by: string;
  approved_by: string | null;
  approved_at: string | null;
  reversal_reason: string | null;
  reversed_by: string | null;
  reversed_at: string | null;
  created_at: string;
  updated_at: string;
  category?: Category;
  creator?: { name: string };
  approver?: { name: string } | null;
}

export interface WalletAccount {
  id: string;
  festival_id: string;
  wallet_name: string;
  opening_balance: number;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  wallet_id: string;
  festival_id: string;
  transaction_number: string;
  type: WalletTxType;
  amount: number;
  source: string | null;
  reference_id: string | null;
  description: string | null;
  status: TransactionStatus;
  created_by: string;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
  creator?: { name: string };
}

export interface LedgerTransaction {
  id: string;
  festival_id: string;
  transaction_number: string;
  transaction_type: LedgerType;
  source_type: string;
  source_id: string | null;
  debit_amount: number;
  credit_amount: number;
  description: string | null;
  created_by: string | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  festival_id: string | null;
  user_id: string | null;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  old_value: any;
  new_value: any;
  ip_address: string | null;
  created_at: string;
  user?: { name: string };
}

export interface Notification {
  id: string;
  festival_id: string | null;
  user_id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

export interface DashboardData {
  totalIncome: number;
  totalExpenses: number;
  currentBalance: number;
  openingBalance: number;
  walletBalance: number;
  pendingIncome: number;
  pendingExpenses: number;
  transactionCount: number;
  recentTransactions: any[];
}

export interface Receipt {
  id: string;
  file_url: string;
  file_name: string;
  file_type: string;
  file_size: number | null;
  uploaded_by: string | null;
  created_at: string;
}
