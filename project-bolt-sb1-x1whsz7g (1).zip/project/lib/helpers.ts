import type { Language } from './i18n';
import { translate, TranslationKey } from './i18n';

export function t(lang: Language, key: TranslationKey): string {
  return translate(lang, key);
}

export function formatCurrency(amount: number): string {
  const formatted = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount || 0);
  return formatted;
}

export function formatDate(date: string | null): string {
  if (!date) return '-';
  return new Date(date).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(date: string | null): string {
  if (!date) return '-';
  return new Date(date).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'APPROVED': return '#2E7D32';
    case 'PENDING': return '#FF8F00';
    case 'REJECTED': return '#C62828';
    case 'CORRECTION_REQUESTED': return '#1565C0';
    case 'REVERSED': return '#795548';
    case 'ACTIVE': return '#2E7D32';
    case 'INACTIVE': return '#9E9E9E';
    case 'COMPLETED': return '#1565C0';
    case 'CANCELLED': return '#C62828';
    case 'DRAFT': return '#9E9E9E';
    default: return '#666666';
  }
}

export function getRoleColor(role: string): string {
  switch (role) {
    case 'SUPER_ADMIN': return '#6A1B9A';
    case 'FESTIVAL_ADMIN': return '#1565C0';
    case 'TREASURER': return '#D4A017';
    case 'COMMITTEE_MEMBER': return '#2E7D32';
    case 'PUBLIC_VIEWER': return '#757575';
    default: return '#666666';
  }
}

export function canApprove(userRole: string, createdBy: string | null, currentUserId: string): boolean {
  if (userRole === 'SUPER_ADMIN' || userRole === 'FESTIVAL_ADMIN') {
    return createdBy !== currentUserId;
  }
  return false;
}

export function canCreateTransaction(userRole: string): boolean {
  return userRole === 'SUPER_ADMIN' || userRole === 'FESTIVAL_ADMIN' || userRole === 'TREASURER';
}

export function canManageFestival(userRole: string): boolean {
  return userRole === 'SUPER_ADMIN' || userRole === 'FESTIVAL_ADMIN';
}

export function canViewAuditLogs(userRole: string): boolean {
  return userRole === 'SUPER_ADMIN' || userRole === 'FESTIVAL_ADMIN';
}

export function isAdmin(userRole: string): boolean {
  return userRole === 'SUPER_ADMIN' || userRole === 'FESTIVAL_ADMIN';
}
