import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { Colors, FontSizes, FontWeight, BorderRadius, Spacing } from '@/lib/theme';
import { formatCurrency } from '@/lib/helpers';

const { width: screenWidth } = Dimensions.get('window');

export function BarChart({ data, labels, title }: { data: number[]; labels: string[]; title?: string }) {
  const maxVal = Math.max(...data, 1);
  const chartWidth = screenWidth - Spacing.xl * 2 - 40;
  const barWidth = chartWidth / Math.max(data.length, 1) - 8;

  return (
    <View style={styles.chartContainer}>
      {title && <Text style={styles.chartTitle}>{title}</Text>}
      <View style={styles.chartArea}>
        <View style={styles.barsRow}>
          {data.map((val, i) => {
            const heightPct = (val / maxVal) * 100;
            return (
              <View key={i} style={styles.barWrap}>
                <Text style={styles.barValue}>{val > 0 ? formatCurrency(val) : ''}</Text>
                <View style={[styles.barTrack, { width: barWidth }]}>
                  <View
                    style={[
                      styles.bar,
                      {
                        height: `${Math.max(heightPct, 2)}%`,
                        backgroundColor: i % 2 === 0 ? Colors.success : Colors.error,
                      },
                    ]}
                  />
                </View>
                <Text style={styles.barLabel}>{labels[i]}</Text>
              </View>
            );
          })}
        </View>
      </View>
    </View>
  );
}

export function PieChart({ data, title }: { data: { label: string; value: number; color: string }[]; title?: string }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const radius = 80;
  const innerRadius = 45;

  if (total === 0) {
    return (
      <View style={styles.chartContainer}>
        {title && <Text style={styles.chartTitle}>{title}</Text>}
        <View style={styles.emptyChart}>
          <Text style={styles.emptyText}>No data</Text>
        </View>
      </View>
    );
  }

  let currentAngle = -90;

  return (
    <View style={styles.chartContainer}>
      {title && <Text style={styles.chartTitle}>{title}</Text>}
      <View style={styles.pieWrap}>
        <View style={styles.pieContainer}>
          <svg width={radius * 2} height={radius * 2} style={styles.pieSvg}>
            {data.map((d, i) => {
              const angle = (d.value / total) * 360;
              const startAngle = currentAngle;
              const endAngle = currentAngle + angle;
              currentAngle = endAngle;

              const startRad = (startAngle * Math.PI) / 180;
              const endRad = (endAngle * Math.PI) / 180;

              const x1 = radius + radius * Math.cos(startRad);
              const y1 = radius + radius * Math.sin(startRad);
              const x2 = radius + radius * Math.cos(endRad);
              const y2 = radius + radius * Math.sin(endRad);

              const largeArc = angle > 180 ? 1 : 0;

              return (
                <path
                  key={i}
                  d={`M ${radius} ${radius} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`}
                  fill={d.color}
                  stroke="#fff"
                  strokeWidth="1"
                />
              );
            })}
            <circle cx={radius} cy={radius} r={innerRadius} fill="#fff" />
          </svg>
          <View style={styles.pieCenter}>
            <Text style={styles.pieTotal}>{formatCurrency(total)}</Text>
          </View>
        </View>
        <View style={styles.legend}>
          {data.map((d, i) => (
            <View key={i} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: d.color }]} />
              <Text style={styles.legendLabel}>{d.label}</Text>
              <Text style={styles.legendValue}>{formatCurrency(d.value)}</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

export function LineChart({ data, labels, title }: { data: number[]; labels: string[]; title?: string }) {
  if (data.length === 0) {
    return (
      <View style={styles.chartContainer}>
        {title && <Text style={styles.chartTitle}>{title}</Text>}
        <View style={styles.emptyChart}>
          <Text style={styles.emptyText}>No data</Text>
        </View>
      </View>
    );
  }

  const maxVal = Math.max(...data, 1);
  const minVal = Math.min(...data, 0);
  const range = maxVal - minVal || 1;
  const chartWidth = screenWidth - Spacing.xl * 2 - 40;
  const chartHeight = 140;
  const stepX = chartWidth / Math.max(data.length - 1, 1);

  const points = data.map((val, i) => {
    const x = i * stepX;
    const y = chartHeight - ((val - minVal) / range) * chartHeight;
    return { x, y, val };
  });

  const pathD = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`)
    .join(' ');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${chartHeight} L 0 ${chartHeight} Z`;

  return (
    <View style={styles.chartContainer}>
      {title && <Text style={styles.chartTitle}>{title}</Text>}
      <View style={styles.lineChartWrap}>
        <svg width={chartWidth} height={chartHeight} style={styles.lineSvg}>
          <defs>
            <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={Colors.primary} stopOpacity="0.3" />
              <stop offset="100%" stopColor={Colors.primary} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={areaD} fill="url(#lineGrad)" />
          <path d={pathD} fill="none" stroke={Colors.primary} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          {points.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r="4" fill="#fff" stroke={Colors.primary} strokeWidth="2" />
          ))}
        </svg>
      </View>
      <View style={styles.lineLabels}>
        {labels.map((l, i) => (
          <Text key={i} style={styles.lineLabel}>{l}</Text>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  chartContainer: {
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
  },
  chartTitle: {
    fontSize: FontSizes.bodyLarge,
    fontWeight: FontWeight.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  chartArea: {
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  barsRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 160,
    gap: 8,
  },
  barWrap: {
    alignItems: 'center',
    flex: 1,
  },
  barValue: {
    fontSize: 10,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
    marginBottom: 4,
  },
  barTrack: {
    height: 120,
    justifyContent: 'flex-end',
    borderRadius: 6,
    overflow: 'hidden',
    backgroundColor: Colors.surfaceAlt,
  },
  bar: {
    width: '100%',
    borderRadius: 6,
  minHeight: 4,
  },
  barLabel: {
    fontSize: 10,
    color: Colors.textTertiary,
    marginTop: 4,
    textAlign: 'center',
  },
  pieWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
  },
  pieContainer: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pieSvg: {
  },
  pieCenter: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pieTotal: {
    fontSize: FontSizes.bodyLarge,
    fontWeight: FontWeight.bold,
    color: Colors.textPrimary,
  },
  legend: {
    flex: 1,
    gap: Spacing.sm,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  legendLabel: {
    fontSize: FontSizes.caption,
    color: Colors.textSecondary,
    flex: 1,
  },
  legendValue: {
    fontSize: FontSizes.caption,
    fontWeight: FontWeight.semibold,
    color: Colors.textPrimary,
  },
  lineChartWrap: {
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  lineSvg: {
  },
  lineLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Spacing.xs,
  },
  lineLabel: {
    fontSize: 10,
    color: Colors.textTertiary,
  },
  emptyChart: {
    height: 120,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: FontSizes.body,
    color: Colors.textTertiary,
  },
});
