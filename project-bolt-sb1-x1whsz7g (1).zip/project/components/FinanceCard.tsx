import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, FontSizes, FontWeight, BorderRadius, Spacing, ShadowStyles } from '@/lib/theme';
import { formatCurrency } from '@/lib/helpers';
import { TrendingUp, TrendingDown, Wallet, Scale, ArrowUpRight, ArrowDownRight } from 'lucide-react-native';

interface FinanceCardProps {
  title: string;
  titleTa?: string;
  amount: number;
  type: 'income' | 'expense' | 'balance' | 'wallet';
  subtitle?: string;
  onPress?: () => void;
}

export function FinanceCard({ title, titleTa, amount, type, subtitle, onPress }: FinanceCardProps) {
  const config = {
    income: {
      gradient: ['#1B5E20', '#2E7D32'] as const,
      icon: <TrendingUp color="#fff" size={22} strokeWidth={2} />,
      arrowIcon: <ArrowUpRight color="#fff" size={16} strokeWidth={2.5} />,
    },
    expense: {
      gradient: ['#C62828', '#E53935'] as const,
      icon: <TrendingDown color="#fff" size={22} strokeWidth={2} />,
      arrowIcon: <ArrowDownRight color="#fff" size={16} strokeWidth={2.5} />,
    },
    balance: {
      gradient: ['#D4A017', '#B8860B'] as const,
      icon: <Scale color="#fff" size={22} strokeWidth={2} />,
      arrowIcon: null,
    },
    wallet: {
      gradient: ['#1565C0', '#1976D2'] as const,
      icon: <Wallet color="#fff" size={22} strokeWidth={2} />,
      arrowIcon: null,
    },
  };

  const c = config[type];

  return (
    <TouchableOpacity
      activeOpacity={onPress ? 0.85 : 1}
      onPress={onPress}
      disabled={!onPress}
    >
      <LinearGradient
        colors={c.gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        <View style={styles.header}>
          <View style={styles.iconWrap}>{c.icon}</View>
          {c.arrowIcon && <View style={styles.arrowWrap}>{c.arrowIcon}</View>}
        </View>
        <View style={styles.body}>
          {titleTa && <Text style={styles.titleTa}>{titleTa}</Text>}
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.amount}>{formatCurrency(amount)}</Text>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.xl,
    minHeight: 140,
    justifyContent: 'space-between',
    ...ShadowStyles.medium,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  arrowWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    marginTop: Spacing.md,
  },
  titleTa: {
    fontSize: FontSizes.caption,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: FontWeight.medium,
    marginBottom: 2,
  },
  title: {
    fontSize: FontSizes.body,
    color: 'rgba(255,255,255,0.9)',
    fontWeight: FontWeight.medium,
    marginBottom: Spacing.xs,
  },
  amount: {
    fontSize: FontSizes.heading,
    color: '#fff',
    fontWeight: FontWeight.bold,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: FontSizes.caption,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: FontWeight.regular,
  },
});
