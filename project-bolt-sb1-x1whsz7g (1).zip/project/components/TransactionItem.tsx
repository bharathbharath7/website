import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Colors, FontSizes, FontWeight, BorderRadius, Spacing } from '@/lib/theme';
import { formatCurrency, formatDate } from '@/lib/helpers';
import { StatusBadge } from './StatusBadge';
import { ArrowUpRight, ArrowDownRight, FileText } from 'lucide-react-native';

interface TransactionItemProps {
  title: string;
  subtitle?: string;
  amount: number;
  date: string;
  status: string;
  type: 'income' | 'expense' | 'ledger';
  transactionNumber?: string;
  onPress?: () => void;
}

export function TransactionItem({
  title,
  subtitle,
  amount,
  date,
  status,
  type,
  transactionNumber,
  onPress,
}: TransactionItemProps) {
  const isIncome = type === 'income';
  const isExpense = type === 'expense';
  const isCredit = type === 'ledger' && amount > 0;

  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={onPress}
      style={styles.container}
    >
      <View
        style={[
          styles.iconWrap,
          {
            backgroundColor: isIncome || isCredit
              ? Colors.successLight
              : Colors.errorLight,
          },
        ]}
      >
        {isIncome || isCredit ? (
          <ArrowUpRight color={Colors.success} size={20} strokeWidth={2.5} />
        ) : (
          <ArrowDownRight color={Colors.error} size={20} strokeWidth={2.5} />
        )}
      </View>

      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={1}>{title}</Text>
        {subtitle && <Text style={styles.subtitle} numberOfLines={1}>{subtitle}</Text>}
        {transactionNumber && <Text style={styles.txnNum}>{transactionNumber}</Text>}
        <Text style={styles.date}>{formatDate(date)}</Text>
      </View>

      <View style={styles.right}>
        <Text
          style={[
            styles.amount,
            { color: isIncome || isCredit ? Colors.success : Colors.error },
          ]}
        >
          {isIncome || isCredit ? '+' : '-'}
          {formatCurrency(amount)}
        </Text>
        <StatusBadge status={status} size="sm" />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: FontSizes.bodyLarge,
    fontWeight: FontWeight.semibold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: FontSizes.caption,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  txnNum: {
    fontSize: FontSizes.caption,
    color: Colors.textTertiary,
    fontFamily: 'monospace',
    marginBottom: 2,
  },
  date: {
    fontSize: FontSizes.caption,
    color: Colors.textTertiary,
  },
  right: {
    alignItems: 'flex-end',
    gap: Spacing.xs,
  },
  amount: {
    fontSize: FontSizes.bodyLarge,
    fontWeight: FontWeight.bold,
  },
});
