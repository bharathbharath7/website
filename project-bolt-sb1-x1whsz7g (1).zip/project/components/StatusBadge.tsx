import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, FontSizes, FontWeight, BorderRadius, Spacing } from '@/lib/theme';
import { getStatusColor } from '@/lib/helpers';

interface StatusBadgeProps {
  status: string;
  label?: string;
  size?: 'sm' | 'md';
}

export function StatusBadge({ status, label, size = 'md' }: StatusBadgeProps) {
  const color = getStatusColor(status);
  const isSmall = size === 'sm';

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: color + '15',
        },
        isSmall && styles.badgeSm,
      ]}
    >
      <View style={[styles.dot, { backgroundColor: color }, isSmall && styles.dotSm]} />
      <Text
        style={[
          styles.text,
          { color },
          isSmall && styles.textSm,
        ]}
      >
        {label || status.replace(/_/g, ' ')}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.md,
    alignSelf: 'flex-start',
  },
  badgeSm: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: Spacing.sm,
  },
  dotSm: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: Spacing.xs,
  },
  text: {
    fontSize: FontSizes.body,
    fontWeight: FontWeight.semibold,
    textTransform: 'capitalize',
  },
  textSm: {
    fontSize: FontSizes.caption,
  fontWeight: FontWeight.medium,
  textTransform: 'capitalize',
  },
});
