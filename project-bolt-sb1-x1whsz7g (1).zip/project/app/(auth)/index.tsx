import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Colors, FontSizes, FontWeight, BorderRadius, Spacing } from '@/lib/theme';
import { useAuth } from '@/lib/auth';
import { Landmark, ShieldCheck, TrendingUp, Users } from 'lucide-react-native';

export default function SplashLanguageScreen() {
  const { user, language, setLanguage } = useAuth();
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(30));

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.ease,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleContinue = () => {
    if (user) {
      router.replace('/(tabs)');
    } else {
      router.replace('/(auth)/login');
    }
  };

  return (
    <LinearGradient
      colors={['#D4A017', '#B8860B', '#8B6914']}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={styles.container}
    >
      <Animated.View
        style={[
          styles.content,
          { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
        ]}
      >
        <View style={styles.logoWrap}>
          <View style={styles.logoCircle}>
            <Landmark color="#D4A017" size={48} strokeWidth={2} />
          </View>
        </View>

        <Text style={styles.appName}>ஊர் திருவிழா கணக்கு</Text>
        <Text style={styles.appNameEn}>Oor Thiruvizha Kanakku</Text>
        <Text style={styles.tagline}>Festival Financial Management</Text>
        <Text style={styles.taglineTa}>திருவிழா நிதி மேலாண்மை</Text>

        <View style={styles.features}>
          <View style={styles.featureItem}>
            <ShieldCheck color="rgba(255,255,255,0.9)" size={20} strokeWidth={2} />
            <Text style={styles.featureText}>Secure Transactions</Text>
          </View>
          <View style={styles.featureItem}>
            <TrendingUp color="rgba(255,255,255,0.9)" size={20} strokeWidth={2} />
            <Text style={styles.featureText}>Central Ledger</Text>
          </View>
          <View style={styles.featureItem}>
            <Users color="rgba(255,255,255,0.9)" size={20} strokeWidth={2} />
            <Text style={styles.featureText}>Transparent Accounts</Text>
          </View>
        </View>

        <View style={styles.languageSection}>
          <Text style={styles.languageTitle}>Select Language / மொழி தேர்வு</Text>
          <View style={styles.languageButtons}>
            <TouchableOpacity
              style={[styles.langBtn, language === 'en' && styles.langBtnActive]}
              onPress={() => setLanguage('en')}
            >
              <Text style={[styles.langBtnText, language === 'en' && styles.langBtnTextActive]}>
                English
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.langBtn, language === 'ta' && styles.langBtnActive]}
              onPress={() => setLanguage('ta')}
            >
              <Text style={[styles.langBtnText, language === 'ta' && styles.langBtnTextActive]}>
                தமிழ்
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity style={styles.continueBtn} onPress={handleContinue} activeOpacity={0.85}>
          <Text style={styles.continueBtnText}>
            {language === 'ta' ? 'தொடர்' : 'Continue'}
          </Text>
        </TouchableOpacity>
      </Animated.View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xl,
  },
  content: {
    alignItems: 'center',
    width: '100%',
  },
  logoWrap: {
    marginBottom: Spacing.xxl,
  },
  logoCircle: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: 'rgba(255,255,255,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  appName: {
    fontSize: FontSizes.largeHeading,
    fontWeight: FontWeight.bold,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 4,
  },
  appNameEn: {
    fontSize: FontSizes.subtitle,
    fontWeight: FontWeight.semibold,
    color: 'rgba(255,255,255,0.85)',
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  tagline: {
    fontSize: FontSizes.body,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
  },
  taglineTa: {
    fontSize: FontSizes.body,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    marginBottom: Spacing.xxxl,
  },
  features: {
    flexDirection: 'row',
    gap: Spacing.lg,
    marginBottom: Spacing.xxxl,
  },
  featureItem: {
    alignItems: 'center',
    gap: 6,
  },
  featureText: {
    fontSize: FontSizes.caption,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: FontWeight.medium,
  },
  languageSection: {
    width: '100%',
    marginBottom: Spacing.xxl,
  },
  languageTitle: {
    fontSize: FontSizes.body,
    color: 'rgba(255,255,255,0.9)',
    textAlign: 'center',
    marginBottom: Spacing.md,
    fontWeight: FontWeight.medium,
  },
  languageButtons: {
    flexDirection: 'row',
    gap: Spacing.md,
    justifyContent: 'center',
  },
  langBtn: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xxl,
    borderRadius: BorderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  langBtnActive: {
    backgroundColor: '#fff',
    borderColor: '#fff',
  },
  langBtnText: {
    fontSize: FontSizes.bodyLarge,
    fontWeight: FontWeight.semibold,
    color: '#fff',
  },
  langBtnTextActive: {
    color: Colors.primary,
  },
  continueBtn: {
    backgroundColor: '#fff',
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.xxxl,
    borderRadius: BorderRadius.xl,
    minWidth: 200,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  continueBtnText: {
    fontSize: FontSizes.bodyLarge,
    fontWeight: FontWeight.bold,
    color: Colors.primary,
  },
});
